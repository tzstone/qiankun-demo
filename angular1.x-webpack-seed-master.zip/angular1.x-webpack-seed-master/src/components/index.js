import Home from './home';
import About from './about';
import angular from 'angular';

export default angular.module('xxx.components', [
    Home,
    About
]).name;